
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class member extends HttpServlet {
	
	public void doGet(HttpServletRequest request,HttpServletResponse response) 
											throws IOException, ServletException {
		
		request.setCharacterEncoding("utf-8");//한글 설정
		
		String id =request.getParameter("id");
		String pwd =request.getParameter("pwd");
		String name =request.getParameter("name");	
		String phone =request.getParameter("phone");
		String email1 =request.getParameter("email1");
		String email2 =request.getParameter("email2");
		String birthY = request.getParameter("birth_yy");
		String birthM = request.getParameter("birth_mm");
		String birthD = request.getParameter("birth_dd");
		String address1 =request.getParameter("address1");
		String address2 =request.getParameter("address2");
		String address3 =request.getParameter("address3");
		String[] hobby =request.getParameterValues("hobby");
		
		response.setContentType("text/html;charset=utf-8");//한글 설정
		
		PrintWriter out= response.getWriter();
		
		
		
		out.println("<HTML>");
		out.println("<HEAD><TITLE>회원가입 정보</TITLE></HEAD>");
		out.println("<BODY>");
		out.println( id + "<br>");
		out.println(pwd + "<br>");
		out.println(name + "<br>");
		out.println(phone + "<br>");
		out.println(email1 + "@" + email2 + "<br>");
		
		out.println(birthY + "<br>");
		out.println(birthM + "<br>");
		out.println(birthD + "<br>");
		out.println(address1 + "<br>");
		out.println(address2 + "<br>");
		out.println(address3 + "<br>");
		if(hobby == null) {
			out.println("취미없음");
		}for (int i = 0; i<hobby.length;i++) {
			out.println(hobby[i] + "");
		}
		out.println("</BODY>");
		out.println("</HTML>");
		
		
	}
}

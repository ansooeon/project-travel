package javabean;

public class ScoreBean {
	//jstlTest11.jsp 를 설명하기 위한 페이지
	// 
	private String name;//이름
	private int point; //성적
	
	public String getName() {
		return name;
		
	}
	
	public void setName(String name) {
		this.name = name;
		
	}
	
	public int getPoint() {
		return point;
	}
	
	public void setPoint(int point) {
		this.point = point;
	}
}

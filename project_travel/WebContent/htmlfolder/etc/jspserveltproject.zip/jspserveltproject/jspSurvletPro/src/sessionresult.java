import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class sessionresult extends HttpServlet {
	
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException {
		HttpSession session = req.getSession(); //  세션 
		String food = (String) session.getAttribute("food"); //가져온 세션을 쓸수있게 형변환 해서 변수 선언
		String animal = req.getParameter("animal"); //전 페이지에서 텍스트에  animal 이름을 가져온다.
		session.invalidate();
		res.setContentType("text/html; charset=utf-8");
		PrintWriter out = res.getWriter();
		
		out.println("<html><head><title>성격테스트</title></head>");
		out.println("<body>");
		out.println("<h3>성격테스트</h3>");
		out.printf("당신은 %s 와 %s를 좋아하는 성격입니다.",food,animal);
		out.println("</body></html>");
		
	}
}

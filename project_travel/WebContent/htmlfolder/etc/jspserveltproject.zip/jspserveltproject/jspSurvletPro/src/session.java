import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class session extends HttpServlet {
	
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException {
		String food = req.getParameter("food");//food를 food 변수에 저장한다.
		HttpSession session = req.getSession();//세션 변수 선언 
		session.setAttribute("food", food);// 가져온 세션을 다시 저장한다. 다음 페이지에서 다시 사용하려고 하기 때문에 이렇 다시 세션을 입력한다.
		res.setContentType("text/html; charset=utf-8");
		PrintWriter out = res.getWriter();
		
		out.println("<html><head><title>성격테스트</title></head>");
		out.println("<body>");
		out.println("<h3>좋아하는 동물</h3>");
		out.println("<form action=sessionresult>");
		out.println("<input type='text' name='animal'>");
		out.println("<input type='submit' value='확인'>");
		out.println("</form>\r\n" + 
				"</body>\r\n" + 
				"</html>");
		
	}
}



import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class hundred extends HttpServlet {
	//설정
	//C:\Program Files\Apache Software Foundation\Tomcat 8.5\webapps\survlet\WEB-INF\classes
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException {
		int total = 0;
		for(int cnt = 1; cnt<101;cnt++) {
			total += cnt;
			PrintWriter out = res.getWriter();
			out.println("<html>");
			out.println("<head><title>Hundred Servlet</title></head>");
			out.println("<body>");
			out.printf("1+2+3+...+100 = %d",total);
			out.println("</body></hrml>");
		}
			
	}
	
}

package Mainpage;

public class MainpageDto {

	private String title;
	private String titlesub;
	private String imgFile;
	private int category;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTitlesub() {
		return titlesub;
	}
	public void setTitlesub(String titlesub) {
		this.titlesub = titlesub;
	}
	public String getImgFile() {
		return imgFile;
	}
	public void setImgFile(String imgFile) {
		this.imgFile = imgFile;
	}
	 
	public int getCategory() {
		return category;
	}
	public void setCategory(int category) {
		this.category = category;
	}
	
		
}

package javatest;

public class SurvletDTO {

	private String pid; 
	private String ppwd; 
	private String pname; 
	private int pyear ;
	private String psnum;
	private String pdepart;
	private String pmobile1; 
	private String pmobile2; 
	private String paddress; 
	private String pemail;
	
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getPpwd() {
		return ppwd;
	}
	public void setPpwd(String ppwd) {
		this.ppwd = ppwd;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPyear() {
		return pyear;
	}
	public void setPyear(int pyear) {
		this.pyear = pyear;
	}
	public String getPsnum() {
		return psnum;
	}
	public void setPsnum(String psnum) {
		this.psnum = psnum;
	}
	public String getPdepart() {
		return pdepart;
	}
	public void setPdepart(String pdepart) {
		this.pdepart = pdepart;
	}
	public String getPmobile1() {
		return pmobile1;
	}
	public void setPmobile1(String pmobile1) {
		this.pmobile1 = pmobile1;
	}
	public String getPmobile2() {
		return pmobile2;
	}
	public void setPmobile2(String pmobile2) {
		this.pmobile2 = pmobile2;
	}
	public String getPaddress() {
		return paddress;
	}
	public void setPaddress(String paddress) {
		this.paddress = paddress;
	}
	public String getPemail() {
		return pemail;
	}
	public void setPemail(String pemail) {
		this.pemail = pemail;
	}
	
	
}



window.onload= function() {

    var Jtext = document.querySelectorAll("input[type=text]");
    var Jmem = document.getElementById("member");
    
    
    var id = document.getElementById("id");
    var name = document.getElementById("name");
    var pwd = document.getElementById("pwd");
    var pwd2 = document.getElementById("pwd2");
    var phone = document.getElementById("phone");
    var email1 = document.getElementById("email1");
    var birth1 = document.getElementById("birth_yy");
    var birth2 = document.getElementById("birth_mm");
    var birth3 = document.getElementById("birth_dd");
    var address1 = document.getElementById("address1");
    var address2 = document.getElementById("address2");
    var address3 = document.getElementById("address3");
    var address = document.getElementById("address_button");

    
    
    Jmem.onclick= function() {
    
        if(id.value == "") {
            
            alert("아이디를 입력해 주세요.");
            id.focus();
            return false;
        } else if(id.value.length < 4 || id.value.length >14) {
            
            alert("아이디는 4자 이상, 14자 이하로 입력해주세요.");
            id.focus();
            return false;
        } else if(name.value == "") {
            
             alert("이름을 입력해 주세요.");
             name.focus();
             return false;

        } else if(pwd.value.length < 4 || pwd.value.length >14) {
            
            alert("비밀번호를 입력해 주세요.");
            pwd.focus();
            return false;	
        } else if(pwd2.value != pwd.value) {
            
            alert("비밀번호 재확인해 주세요.");
            pwd2.focus();
            return false;
        } else if(phone.value == "") {
            
            alert("휴대 전화번호를 입력해 주세요.");
            phone.focus();
            return false;
        }else if(email1.value == "") {
            
            alert("이메일을 입력해 주세요.");
            email1.focus();
            return false;
        } else if(birth1.value == "") {
        
            alert("년도을 선택해 주세요.");
            birth1.focus();
            return false;
        }else if(birth2.value == "") {
        
            alert("월을 선택해 주세요.");
            birth2.focus();
            return false;
        }else if(birth3.value == "") {
        
            alert("요일을 선택해 주세요.");
            birth3.focus();
            return false;
        }else if(address1.value == "") {
            
            alert("우편번호를 입력해 주세요.");
            address1.focus();
            return false;
        } else if(address2.value == "") {
            
            alert("주소를 입력해 주세요.");
            address2.focus();
            return false;
        }else if(address3.value == "") {
            
            alert("상세주소를 입력해 주세요.");
            address3.focus();
            return false;
        }else {
            
            alert("회원가입 성공!");
            location.href="MainPage.html";
        }
        
    }
    
    
        $('#loginBtn').click(function(){
            $.ajax({
                url:"",
                success : function() {
                    if (id.value.length < 4 || id.value.length >14) {
                        $("#checkId").html('사용할수 없는 아이디 입니다.');
                        
                    } else {
                        $("#checkId").html('사용할수 있는 아이디 입니다.');
                        
                    }
                },
                error: function() {
                    alert("실패");
                }
            })
        })
    

    $('#pwd').focusout(function(){

        $.ajax({
            url:"",
            success : function() {
                if (pwd.value.length < 4 || pwd.value.length >14) {
                    $("#checkPwd").html('패스워드는 4자 이상, 14자 이하로 입력해주세요.');
                    $("#checkPwd").attr("color","red");
                } else {
                    $("#checkPwd").html('');
                }
            },
            error: function() {
                alert("실패");
            }
        })
    })
    address.onclick= function () {
        new daum.Postcode({
            oncomplete: function(data) {
                // 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.
    
                // 각 주소의 노출 규칙에 따라 주소를 조합한다.
                // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
                var addr = ''; // 주소 변수
                var extraAddr = ''; // 참고항목 변수
    
                //사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
                if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우
                    addr = data.roadAddress;
                } else { // 사용자가 지번 주소를 선택했을 경우(J)
                    addr = data.jibunAddress;
                }
    
                // 사용자가 선택한 주소가 도로명 타입일때 참고항목을 조합한다.
                if(data.userSelectedType === 'R'){
                    // 법정동명이 있을 경우 추가한다. (법정리는 제외)
                    // 법정동의 경우 마지막 문자가 "동/로/가"로 끝난다.
                    if(data.bname !== '' && /[동|로|가]$/g.test(data.bname)){
                        extraAddr += data.bname;
                    }
                    // 건물명이 있고, 공동주택일 경우 추가한다.
                    if(data.buildingName !== '' && data.apartment === 'Y'){
                        extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
                    }
                    // 표시할 참고항목이 있을 경우, 괄호까지 추가한 최종 문자열을 만든다.
                    if(extraAddr !== ''){
                        extraAddr = ' (' + extraAddr + ')';
                    }
                    // 조합된 참고항목을 해당 필드에 넣는다.
                    document.getElementById("address3").value = extraAddr;
                
                } else {
                    document.getElementById("address3").value = '';
                }
    
                // 우편번호와 주소 정보를 해당 필드에 넣는다.
                document.getElementById('address1').value = data.zonecode;
                document.getElementById("address2").value = addr;
                // 커서를 상세주소 필드로 이동한다.
                document.getElementById("address3").focus();
            }
        }).open();
    }

    $(function () {

		$('.nb').hide();
       
        $('.util_nav').mouseenter(function(){
            $(".nb").slideDown("slow");
        });

        $('.nb').mouseleave(function(){
            $(".nb").slideUp("middle");
			
        });
	})

}
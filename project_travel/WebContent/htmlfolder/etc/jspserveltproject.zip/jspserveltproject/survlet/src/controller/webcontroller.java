package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.dto;

public class webcontroller extends HttpServlet {

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// service doget,dopost에 메소드를 같이 인식한다.
		// 서비스 요청을 받는 페이지
		// dbdata.java 로 갔다가 되돌아온다.
		// 서비스 처리후 출력 페이지로 내보낸다.
		InsertSql interinsert = null;
		DbSql interf = null;// interface 불러와 변수 처리
		
		interinsert = insertdata.getinstance();
		interf = dbdata.instance(); // 변수에 dbdata.java 에 변수 넣음
		
		req.setCharacterEncoding("utf-8");

		try {

			String comm = req.getParameter("comm");
			if(comm.equals("writer")) {
				// 1번	
				int insertdb = interinsert.insertData(req, res); // insert 실행 명령어
				res.sendRedirect("dataprint.jsp?comm=list");

			}else if(comm.equals("list")) {
				// 1번
				List<dto> db = interf.dbData(req, res);
				RequestDispatcher dispatcher = req.getRequestDispatcher("dataprint.jsp");// 데이터를 데리고 이 페이지로 이동하는 페이지 넘기는 방법 **
				dispatcher.forward(req, res);
			}

		} catch (Exception e) {
			System.out.println(e);//에러 내용 콘솔 출력
		}

	}

}

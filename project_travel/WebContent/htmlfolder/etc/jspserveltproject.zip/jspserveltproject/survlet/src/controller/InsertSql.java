package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface InsertSql {
	
	//insert 작업을 처리하기 위한 인터페이스

	int insertData(HttpServletRequest req, HttpServletResponse res) throws Exception;
	
}

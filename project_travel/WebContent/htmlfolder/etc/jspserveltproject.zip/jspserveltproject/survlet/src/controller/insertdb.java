package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import dto.dto;
import mybatis.mybatis;

public class insertdb {

	// 3
	// insertdata 에서 넘어온다.
	static insertdb id = new insertdb();

	public static insertdb getinstantce() {
		// singleton 패턴
		// 다른곳에서도 객체 선언을 하지않고 사용할수 있게 하기위해
		return id;
	}

	public int insertInfo(HttpServletRequest req, HttpServletResponse res) throws Exception {

		dto dto = new dto();

		dto.setCode(req.getParameter("code"));
		dto.setTitle(req.getParameter("title"));
		dto.setWriter(req.getParameter("writer"));
		dto.setPrice(Integer.parseInt(req.getParameter("price")));

		SqlSessionFactory sqlfac = mybatis.getSqlSession();// db 연결
		SqlSession session = sqlfac.openSession();// web.xml과 연결.
		int insert = session.insert("UserMapper.insertData", dto);

		session.commit();

		return insert;

	}

}

package controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.dto;

public class dbdata implements DbSql {

	// 2번
	// db 내용(select)을 가져오는 파일
	// db를 처리하는 파일
	// 작업하나를 처리할때마다 파일을 분리하는 것이 유지보수에 용이하다.
	// selectdb.java로 갔다가 서비스를 처리하고 돌아온다ㅏ.
	// webcontroller.java로 되돌아간다.

	static dbdata da = new dbdata();

	public static dbdata instance() {
		// singleton 패턴
		// 다른곳에서도 객체 선언을 하지않고 사용할수 있게 하기위해
		return da;
	}

	@Override
	public List<dto> dbData(HttpServletRequest req, HttpServletResponse res) throws Exception {

		selectdb sd = selectdb.instantce(); // selectdb.java에서 싱글톤 방식으로 만든 메소드를 불러왔다\\

		List<dto> list = sd.selectInfo();

		req.setAttribute("list", list);

		return list;

	}

}

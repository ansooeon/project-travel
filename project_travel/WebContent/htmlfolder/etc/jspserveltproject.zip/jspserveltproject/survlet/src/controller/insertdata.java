package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class insertdata implements InsertSql {

	// 2
	// db를 입력하기 위한 파일
	// webcontroller.java로 되돌아간다.

	static insertdata id = new insertdata();

	public static insertdata getinstance() {
		return id;
	}

	@Override
	public int insertData(HttpServletRequest req, HttpServletResponse res) throws Exception {
		// TODO Auto-generated method stub
		insertdb id = insertdb.getinstantce();

		int insert = id.insertInfo(req, res);

		req.setAttribute("insert", insert);

		return insert;
	}

}

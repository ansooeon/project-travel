package controller;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import dto.dto;
import mybatis.mybatis;

public class selectdb {
	// 3 번
	//DB 내용을 가져오는 파일
	//dbdata.java 로 되돌아간다.
	
	static selectdb sd = new selectdb();
	public static selectdb instantce() {
		//singleton 패턴
		//다른곳에서도 객체 선언을 하지않고 사용할수 있게 하기위해
		return sd; 
	}
	
	//mybatis.java 와 연결
	SqlSessionFactory sqlfac =mybatis.getSqlSession();
	
	public List<dto> selectInfo() {
		
		SqlSession session =  sqlfac.openSession();//web.xml과 연결.
		
		List<dto> list = session.selectList("UserMapper.selectAll");//MybatisMapper.xml에서 select문을 가져온다.
	
		session.close();
		
		return list;
	}
	

}
	
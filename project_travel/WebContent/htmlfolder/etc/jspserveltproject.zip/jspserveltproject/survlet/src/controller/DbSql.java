package controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface DbSql {
	// 만든이유: 기본적으로 데이터 처리
	// select 문을 위한 파일ㄴ
	List dbData(HttpServletRequest req, HttpServletResponse res) throws Exception;
	
}
